package com.frame;

import java.util.ArrayList;

public interface Search<K,V> {
	public ArrayList<V> search(K k);
}

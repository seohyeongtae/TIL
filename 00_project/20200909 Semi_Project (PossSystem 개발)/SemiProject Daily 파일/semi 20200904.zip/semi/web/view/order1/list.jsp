<%@ page language="java" contentType="text/html; charset=EUC-KR"
    pageEncoding="EUC-KR"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%> 


<style>
	#listpage > h3 > img{
		width : 50px;
	}

</style>   

     
<div id="listpage">
<h1>Select All Page</h1>

<c:forEach var="s" items="${menulist }">
	<h3><img src="img/${s.img1 }"><a href="orderlist.mc?id=${s.id }">${s.id } ${s.name }  
	${s.price }  ${s.tsales } ${s.img1 } </a></h3>
</c:forEach>


</div>
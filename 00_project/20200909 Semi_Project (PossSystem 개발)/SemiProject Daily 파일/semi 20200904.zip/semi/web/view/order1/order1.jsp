<%@ page language="java" contentType="text/html; charset=EUC-KR"
    pageEncoding="EUC-KR"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%> 


<style>
	#listpage > h3 > img{
		width : 50px;
	}

</style>   
        
<div id="orderpage">
<h1>Order Page</h1>

	<img src="img/${orderlist.img1 }">
	<a href="orderlist.mc?id=${orderlist.id }"> ${orderlist.name } ${orderlist.price }</a>  
	<h3> </h3>



</div>
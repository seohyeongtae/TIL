<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
 
 
<style>
	#menulist > h3 > img{
		width : 50px;
	}

</style>   
        
<div id="meunlist">
<h1>Order Page</h1>

	<img src="img/${orderlist.img1 }">
	<a href="orderlist.mc?id=${orderlist.id }"> ${orderlist.name } ${orderlist.price }</a>  
	<h3> </h3>



</div>
package com.test;

import java.util.ArrayList;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.frame.Biz;
import com.vo.Sales;

public class Appsales {

	public static void main(String[] args) {
		System.out.println("App Start .......");
		AbstractApplicationContext factory = 
		new GenericXmlApplicationContext("myspring.xml");
		System.out.println("Spring Started .......");

		// IoC
		
		Biz<String, Sales> biz = 
				(Biz)factory.getBean("bulletinbiz");

		try {
			biz.remove("");
			System.out.println("OK");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		ArrayList<Sales> list = null;
		try {
			list = biz.get();
			for(Sales co:list) {
				System.out.println(co);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	
		
		
		
		
//		ArrayList<ContentsVo> list = null;
//		HashMap<String, Integer> smap = new HashMap<>();
//		smap.put("start", 20);
//		smap.put("end", 30);
//		try {
//			list = biz.search(smap);
//			for(ContentsVo cv:list) {
//				System.out.println(cv);
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
		
		
//		Menu c = new Menu("title3","contents3","james");

		

//		ContentsVo dbuser = null;
//		try {
//			dbuser = biz.get(100);
//			System.out.println("RESULT: "+dbuser);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		
//

//		ContentsVo uc = new ContentsVo(100,"title444","con4444");
//		 try {
//			biz.modify(uc);
//			System.out.println(uc);
//		} catch (Exception e) {
//
//			e.printStackTrace();
//		}
		
		
//		
//		Item item = new Item("�ǳ�", 12345);
//		try {
//			service.register(item);
//			System.out.println("OK");
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
		
	
		
//		Item dbitem = null;
//		try {
//			dbitem = (Item) service.get(1);
//			System.out.println("RESULT: "+dbitem);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
		
//		ArrayList<Item> list = null;
//		try {
//			list = service.get();
//			for(Item i:list) {
//				
//				System.out.println(i);
//			}
//		} catch (Exception e) {
//			System.out.println("Fail");
//			e.printStackTrace();
//			
//		}
		
//		ArrayList<Item> list = null;
//		try {
//			list = service.get();
//			for(Item i:list) {
//				
//				System.out.println(i);
//			}
//		} catch (Exception e) {
//			System.out.println("Fail");
//			e.printStackTrace();
//			
//		}
		
		
//		Search itemservice = (Search) factory.getBean("itemservice");
//
//		ArrayList<Item> list2 = null;
//		try {
//			list2 = itemservice.search();
//			System.out.println(list2);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
	
//		Search userservice = (Search) factory.getBean("userservice");
//
//		ArrayList<User> list2 = null;
//		try {
//			list2 = userservice.search();
//			System.out.println(list2);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
		
		
		
		factory.close();
		System.out.println("Spring End .......");
		System.out.println("App End .......");

	}

}



<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="EUC-KR"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%> 


<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>

<style>

/*------whole div Start------ */

#right-div,#left-div{
	padding-top:50px;
}
.row{
	text-align: center;
}
/*------whole div end------ */

/*------left div Start------ */
#left-div>h1{
	text-align: left;
}
#order> div{
	margin: 0 auto;
	text-align: left;
}
#order>#cate{
	height: 47px;
	padding:0;
}
#order>#menu{
	background: white;
	border: 2px solid gray;
	height: 450px;
	overflow: auto;
}
/*------left div end------ */

/*------left div category Start------ */
#cate>a{
	padding: 0;
	font-size: 25px;
	color: black;
	margin: 0;
	display:inline-block;
	text-align: center;
	background: white;
	border: 1px solid gray;
}
/*------left div category end------ */

/*------right div Start------ */
#right-div>div{
	border: 1px solid gray;
	height: 375px;
	overflow: auto;
}
#right-div>h1{
	margin-top:5px;
	margin-bottom:5px;
}
#right-div>#orderbtn{
	display:block;
}

/*------right div end------ */

</style>


<script>
	
	var menulist = new Array();


	/*MenuController�� �޴� ����Ʈ ���� �ޱ�*/
function sendData(id){
	$.ajax({
		url:'/semi/menulist.mc',
		async:false,
		dataType:"json",
		data:{id:id},
		success:function(result){
			display(result);
		},
		error: function(jqXHR, textStatus, errorThrown){
			alert(errorThrown);
			alert(textStatus);
		}
	});
};

	/*MenuController�� �޴� ����Ʈ ���� ������ ȭ�鿡 ǥ���ϱ�*/
function display(datas){
	$('#menu').empty();
	$(datas).each(function(index,menu){
		var result = '';
		result += '<h3> <a type="button" href="javascript:void(0);" num ="';
		result += menu.id+	'">';
		result += '<img src="img/' + menu.img1 + ' "></a><br>';
		result += menu.name +',  ���� = '+menu.price;
		result += '</h3>';
		
		$('#menu').append(result);
});
	/*�޴� ����Ʈ ���� ������ order ����Ʈ�� �Էµǰ� �ϴ� �Լ� ����*/
		orderready();
};		



	/* �ֹ���� �ش� �� ����, ���հ�ݾ� ���� dispalyorder Button���� ���� */
function deleteRow(ths){
	var $ths = $(ths);
	$ths.parents("h3").remove();
	var delnum = $(ths).attr('value');
	deletetotal = $('#right-div > h1 > span').html() - Number(delnum);	
	$('#right-div > h1 > span').html(deletetotal);
	}

	
	
	/*+ - ���� ���� �� �� �ݾ� ���� */
function change(num, id){
	
	var x = (document.getElementById("qtcount"+id).value);
	var y = (Number(x) + Number(num));
	
	if(y >= 1){
	document.getElementById("qtcount"+id).value = y;
	var delqt = $('#qtcount'+id).attr('name');

	
	deleteqt = Number($('#right-div > h1 > span').html()) + Number(delqt)*Number(num);
	$('#right-div > h1 > span').html(deleteqt);
	
	}else{
		document.getElementById("qtcount"+id).value = 1;
	};
};
	/* �޴� �ߺ�*/
function overlap(){
	var idname = $('#order-list > h3').attr('id');
	menulist.reverse();
	var overname =  menulist.slice(-1);
	if(idname == overname){
		alert("�̹� �����Ͻ� �޴��Դϴ�.")
		$('h3').remove;
	};
	
};


		/*�̹��� ������ ��ü �ֹ���϶��� ǥ��*/
function displayorder(datas){
	$(datas).each(function(index,menu){
		function total(){
			var total = '';
			total = Number(menu.price) + Number($('#right-div > h1 > span').html());
			$('#right-div > h1 > span').html(total);
		};
		
		menulist.push(menu.id, menu.name, menu.price, menu.tsale, menu.category, menu.img1, menu.img2, menu.img3);
		
		var result = '';
		result += '<h3 id="'+menu.id+'">';
		result +=  menu.name +'  '+menu.price;
		

		result += '<button type="button" onclick="change(1, '+menu.id+');" id="plus'+menu.id+'">+</button>'
		result += '<input type="text" id="qtcount'+menu.id+'" value="1" size = 1 name ="'+menu.price+'">'
		result += '<button type="button" onclick="change(-1, '+menu.id+');" id="minus'+menu.id+'">-</button>'
		
		
		result += '<button type="button" value="'+menu.price+'" onclick = "deleteRow(this);">X</button>';
		result += '</h3>';
		$('#order-list').append(result);
		var price = '';
		price += parseInt(menu.price);
		total();	
		overlap();
			
	});
	
};		
	/*�ֹ���Ͽ�  display���� �̹��� Ŭ���ϸ� Id ���� �Ѿ�´� ������ ��������*/
function orderlist(id){
	$.ajax({
		url:'/semi/orderlist.mc',
		async:false,
		dataType:"json",
		data:{id:id},
		success:function(result){
			displayorder(result);
		},
		error: function(jqXHR, textStatus, errorThrown){
			alert(errorThrown);
			alert(textStatus);
		}
	});
};


	/*�޴���Ͽ��� (display)  �޴����������� �̹��� Ŭ���� ���� �Լ� �����غ�*/
function orderready(){
		$('#menu > h3 > a').click(function(){
			var num = $(this).attr("num");
			orderlist(num);	
		});
	}; 
	
</script>



<section class="pb_cover_v1 text-center" style="background-color: #fff5b9" id="section-table-order">
	<div class="container">
		<div class="row align-items-center justify-content-center">
			<div class="col-sm-8" id="left-div">
				<h1>�ֹ��ϱ�</h1>
				<div id="order">
					<div id="cate" class="row">
<!-- 					 	<a class="col-sm-3" type="button" id="cate-food" href="#" num ='1'>�Ļ�</a>
						<a class="col-sm-3" type="button" id="cate-fruit" href="#" num ='2' >����</a>
						<a class="col-sm-3" type="button" id="cate-anju" href="#" num ='3'>����</a>
						<a class="col-sm-3" type="button" id="cate-drink" href="#" num ='4'>����</a>
						 -->
						 
						 <!--  onclick �����߽��ϴ� - ������ -->
						<a class="col-sm-3" type="button" id="cate-food" href="javascript:void(0);" onclick="sendData(1)">�Ļ�</a>
						<a class="col-sm-3" type="button" id="cate-fruit" href="javascript:void(0);" onclick="sendData(2)" >����</a>
						<a class="col-sm-3" type="button" id="cate-anju" href="javascript:void(0);" onclick="sendData(3)">����</a>
						<a class="col-sm-3" type="button" id="cate-drink" href="javascript:void(0);" onclick="sendData(4)">����</a> 
					</div>
					<div id="menu">
					</div> 
				</div>
			</div>
			<div class="col-sm-4" id="right-div">
				<h1>�ֹ� ���</h1>
				<div id="order-list"></div>
				<h1>Total : <span>0</span> ��</h1>
				<a type="button" id="orderbtn" href="tablereceipt.mc" class="custombtn">�ֹ��ϱ�</a>
			</div>
		</div>
	</div>
</section>
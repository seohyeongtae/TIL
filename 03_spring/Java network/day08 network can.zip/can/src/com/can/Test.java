package com.can;

import java.io.IOException;

import gnu.io.CommPortIdentifier;

public class Test  {

	private CommPortIdentifier portIdentifier;

	// private boolean start = false;

	public Test(String portName, boolean mode) {

		try {
			if (mode == true) {
				portIdentifier = CommPortIdentifier.getPortIdentifier(portName);
				System.out.printf("Port Connect : %s\n", portName);
				
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	

	public static void main(String args[]) throws IOException {
		// 컴퓨터 포트 Num
		Test ss = new Test("COM5", true);
	
	}

}

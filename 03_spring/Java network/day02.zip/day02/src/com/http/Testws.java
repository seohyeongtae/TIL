package com.http;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class Testws {

	public static void main(String[] args) {
		String urlstr = "http://192.168.1.107:8000/network/login.jsp";
		URL url = null;
		HttpURLConnection con = null;
		
	//	InputStream is = null;
	//	InputStreamReader isr = null;
		BufferedReader br = null;
		try {
			String id = "qqq";
			String pwd = "111";
			url = new URL(urlstr+"?id="+id+"&pwd="+pwd);
			con = (HttpURLConnection) url.openConnection();
			con.setRequestMethod("POST");
			con.getInputStream();
			
		//	is = con.getInputStream();
		//	isr = new InputStreamReader(is);
			// br = new BufferedReader(isr);
			
			br = new BufferedReader(
					new InputStreamReader(con.getInputStream()) 
					);
			
			String str = "";
			while((str = br.readLine()) != null) {
				System.out.println(str.trim());
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(br != null) {
				try {
					br.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			con.disconnect();
		}
	}

}

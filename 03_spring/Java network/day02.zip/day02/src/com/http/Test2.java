package com.http;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

public class Test2 {

	public static void main(String[] args) {
		// spring �� �ִ� users.jsp ���� ���� ������ ����
		String urlstr = "http://192.168.1.107:8000/network/mp.mp3";
		URL url = null;
		URLConnection con = null;
		
		// ���ϰ��������� InputStream �� byte �� �޾ƿ´�.
		InputStream is = null;
		BufferedInputStream bis = null;
		
		// �� ��ǻ�Ϳ� ����
		FileOutputStream fos = null;
		BufferedOutputStream bos = null;

		try {
			url = new URL(urlstr);
			con = url.openConnection();
			is = con.getInputStream();
			bis = new BufferedInputStream(is,10240000);
			
			// ���� ����
			fos = new FileOutputStream("newmp.mp3");
			bos = new BufferedOutputStream(fos);
			
			int data =0;
			while ((data = bis.read()) != -1){
				bos.write(data);
				//System.out.println(data);
			}
		
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(bis != null) {
				try {
					bis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if(bos != null) {
				try {
					bos.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

	}

}

package com.tcpip;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {

	int port;
	String ip;

	Socket socket;

	OutputStreamWriter ow;
	BufferedWriter bw;

	public Client(String ip, int port) {
		this.ip = ip;
		this.port = port;
	}

	public void connectServer() {
		try {
			System.out.println("Start Client");
			socket = new Socket(ip, port);
			System.out.println("Connected...");
		} catch (Exception e) {
			// ������ ���� �ʾ��� ��� ��� ��õ�
			while (true) {
				try {
					Thread.sleep(2000);
					socket = new Socket(ip, port);
					System.out.println("Connected...");
					break;
				} catch (Exception e1) {
					System.out.println("Re Try...");
				}
			} // while end
		}
	} // connectServer end

	// server �� ������ ������
	public void request(String msg) throws IOException {
		// try catch �� close�� ���� ������ Server ���� ������ ���.
		try {
			ow = new OutputStreamWriter(socket.getOutputStream());
			bw = new BufferedWriter(ow);
			bw.write(msg);
		} catch (Exception e) {
			throw e;
		}
	} // request end

	public void close() throws IOException {
		if (bw != null) {
			bw.close();
		}
		if (socket != null) {
			socket.close();
		}
	} // close end

	public static void main(String[] args) {
		Client client = null;
		client = new Client("192.168.1.107", 9999);
		client.connectServer();
				
		Scanner sc = new Scanner(System.in);
		while(true) {
			System.out.println("Input msg");
			String msg = sc.nextLine();
			if(msg.equals("q")) {
				try {
					client.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
				break;
			}
			try {
				client.request(msg);
			} catch (IOException e) {
				e.printStackTrace();
			}
		} // while end
		
		System.out.println("End Client");
	}

}

<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%> 
    
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>

<style>

#msg {
	text-align : left;
	border: 2px solid gray;
}
</style>

<script>

function display(datas){
	$('msg').append(datas)
};


/* function msg(){
	$.ajax({
		url:'/getmsg.mc',
		async : false,
		dataType : "json",
		success:function(data){
			display(data)
		},
		error : function(jqXHR, textStatus, errorThrown) {
			alert(errorThrown);
			alert("안돼냐");
		}
	});
	
}; */


$(document).ready(function(){
	$('#iot').click(function(){
		$.ajax({
			url:'iot.mc',
			success:function(data){
				alert('Send Complete...')
			/* 	msg(); */
			}
		});
	});
	$('#phone').click(function(){
		$.ajax({
			url:'phone.mc',
			success:function(data){
				alert('Send Complete...')
			}
		});
	});
	$('#controllcan').click(function(){
		$.ajax({
			url:'controllcan.mc',
			success:function(data){
				alert('Send Complete...')
			}
		});
	});
	$('#msgb').click(function(){
	$.ajax({
		url:'getmsg.mc',
		async : false,
		dataType : "json",
		success:function(data){
			display(data)
		},
		error : function(jqXHR, textStatus, errorThrown) {
			alert(errorThrown);
			alert("안돼냐");
		}
	});
	});
});

</script>


</head>
<body>

<h1>Main Page</h1>
<h2><a id="iot" href="#">Send IoT(TCP/IP)</a></h2>
<h2><a id="phone" href="#">Send Phone(FCM)</a></h2>
<h2><a id="msgb" href="#">msgbt</a></h2>
<h2><a id="controllcan" href="#">Can on</a></h2>

<div id ='msg'></div>



</body>
</html>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%> 
    
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>


<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js" type="text/javascript" charset="utf-8"></script>


<style>

#msg {
	text-align : left;
	border: 2px solid gray;
}
</style>

<script>

function display(datas){
	$('msg').append(datas)
};


/* function msg(){
	$.ajax({
		url:'/getmsg.mc',
		async : false,
		dataType : "json",
		success:function(data){
			display(data)
		},
		error : function(jqXHR, textStatus, errorThrown) {
			alert(errorThrown);
			alert("안돼냐");
		}
	});
	
}; */


$(document).ready(function(){
	
	 var gqrapi = "http://chart.apis.google.com/chart?cht=qr&chs=144x144&choe=UTF-8&chld=H|0";
	
	
	
	
	$('#iot').click(function(){
		$.ajax({
			url:'iot.mc',
			success:function(data){
				alert('Send Complete...')
			/* 	msg(); */
			}
		});
	});
	$('#phone').click(function(){
		$.ajax({
			url:'phone.mc',
			success:function(data){
				alert('Send Complete...')
			}
		});
	});
	$('#controllcan').click(function(){
		$.ajax({
			url:'controllcan.mc',
			success:function(data){
				alert('Send Complete...')
			}
		});
	});
	$('#msgb').click(function(){
	$.ajax({
		url:'getmsg.mc',
		async : false,
		dataType : "json",
		success:function(data){
			display(data)
		},
		error : function(jqXHR, textStatus, errorThrown) {
			alert(errorThrown);
			alert("안돼냐");
		}
	});
	});
	
	
	
	$("#gobtn").click(function () {
		  $text = $("#text").val();

		//입력한 내용 있는지 체크
		  if ($text !== "") {
		   var imgsrc = gqrapi+"&chl="+encodeURIComponent($text); //입력 데이터 인코딩해서 구글 API에 파라메터로 붙이고...

		//이미지 객체를 생성해서 구글API URL을 "src="로 지정

		   var img = new Image();
		   $(img).load(function (){
		    var $this = $(this);
		    $this.hide();
		    $("#qrout").empty().append(this); //<div></div>에 이미지 객체를 덧붙이고...

		    $this.fadeIn(); //블로그에 붙이고 수정하다 잘라먹었습니다. 실행안되시는분은 이줄이 빠져서 만들어진 QR코드가 화면에 안보이는겁니다.

		   }).attr({"src" : imgsrc, "width" : 144, "height" : 144, "alt" : "QR CODE: "+$("#text").val()}); //이미지 객체의 속성 지정 "src"에 구글API URL 지정
		  } else {
		   $("#qrout").empty().text("인코딩할 데이터를 입력하세요.");
		  }
		 });


	
	
	
	
	
});

</script>


</head>
<body>

<h1>Main Page</h1>
<h2><a id="iot" href="#">Send IoT(TCP/IP)</a></h2>
<h2><a id="phone" href="#">Send Phone(FCM)</a></h2>
<h2><a id="msgb" href="#">msgbt</a></h2>
<h2><a id="controllcan" href="#">Can on</a></h2>

<div id ='msg'></div>

<div id="cont">
 <form method="get" action="none">
  <fieldset>
  <legend>QR Code 생성</legend>
  <label for="text">인코딩할 데이터: </label>
  <input type="text" name="text" id="text" size="100" />
  <input type="button" name="go" id="gobtn" value="QR Code 생성" />
  </fieldset>
 </form>
 <div id="qrout"></div>
</div>



</body>
</html>
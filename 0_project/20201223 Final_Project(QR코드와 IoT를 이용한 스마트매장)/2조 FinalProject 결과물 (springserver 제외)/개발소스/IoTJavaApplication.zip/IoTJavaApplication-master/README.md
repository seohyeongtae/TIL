# IoTJavaApplication
AWS에 전개된 TCP/IP 서버와 IoT 장비 내의 Arduino와 통신하기 위한 JavaApplication

# Arduino 폴더만 보면 됩니다.

package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.dao.MenuDao;
import com.frame.Biz;
import com.vo.Menu;

@Controller
public class MenuController {


	
	@Resource(name = "menubiz")
	Biz<String, Menu> biz;

	
	@Autowired
	MenuDao menubiz;
	
	// 1���� �޴� ����
	@RequestMapping("/orderlist")
	public void orderlist(HttpServletRequest request, HttpServletResponse response) {
		String id = request.getParameter("id");
		Menu m = new Menu();
		try {
			m = menubiz.select(id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		JSONArray ja = new JSONArray();
			JSONObject obj = new JSONObject();
			obj.put("id", m.getId());
			obj.put("name", m.getName());
			obj.put("price", m.getPrice());
			obj.put("tsales", m.getTsales());
			obj.put("category", m.getCategory());
			obj.put("img1", m.getImg1());
			obj.put("img2", m.getImg2());
			obj.put("img3", m.getImg3());
			ja.add(obj);
		response.setContentType("text/json;charset=euc-kr");
		PrintWriter out;
		try {
			out = response.getWriter();
			out.print(ja.toJSONString());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
	
	//  �޴� ����Ʈ ����
	@RequestMapping("/menulist")
	public void menulist(HttpServletRequest request, HttpServletResponse response) {
		String id = request.getParameter("id");
		ArrayList<Menu> list = null;
		try {
			list = menubiz.getmenulist(id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		JSONArray ja = new JSONArray();
		for(Menu m: list) {
			JSONObject obj = new JSONObject();
			obj.put("id", m.getId());
			obj.put("name", m.getName());
			obj.put("price", m.getPrice());
			obj.put("tsales", m.getTsales());
			obj.put("category", m.getCategory());
			obj.put("img1", m.getImg1());
			obj.put("img2", m.getImg2());
			obj.put("img3", m.getImg3());
			ja.add(obj);
		}
		response.setContentType("text/json;charset=euc-kr");
		PrintWriter out;
		try {
			out = response.getWriter();
			out.print(ja.toJSONString());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	

	}
	

	
//	// 1���� �޴� ����
//	@RequestMapping(value="/orderlist.do", method=RequestMethod.POST)
//	public Menu orderlist(String id) {
//		Menu order = null;
//		try {
//			order = biz.get(id);
//		}catch (Exception e) {
//			e.printStackTrace();
//		}
//		return order;
//	}
	
	
//	@RequestMapping("/menuupdate")
//	public ModelAndView menuupdate(ModelAndView mv, String id);
	
}

package com.controller;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.biz.MenuBiz;
import com.dao.MenuDao;
import com.frame.Biz;
import com.vo.Menu;

/**
 * Servlet implementation class GetOrderlistServlet
 */

@WebServlet({ "/GetOrderlistServlet", "/orderlist" })
public class GetOrderlistServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	@Resource(name = "menubiz")
	Biz<String, Menu> biz;

	
	@Autowired
	MenuDao menubiz;
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ArrayList<Menu> list = null;
		String id = request.getParameter("categoryN");
		System.out.println(id);
		try {
			list = menubiz.getmenulist(id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(list);
		
		
		JSONArray ja = new JSONArray();
		for(Menu m: list) {
			JSONObject obj = new JSONObject();
			obj.put("id", m.getId());
			obj.put("name", m.getName());
			obj.put("price", m.getPrice());
			obj.put("tsales", m.getTsales());
			obj.put("category", m.getCategory());
			obj.put("img1", m.getImg1());
			obj.put("img2", m.getImg2());
			obj.put("img3", m.getImg3());
			ja.add(obj);
		}
		
		System.out.println(ja);
		response.setContentType("text/json;charset=utf-8");
		PrintWriter out = response.getWriter();	
		out.print(ja.toJSONString());

		
	}
	
	
	

}

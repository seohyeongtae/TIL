package com.connect;

public class Connect {
	private String urlstr;
}

package com.vo;

public class Stores {
	
	private String name;
	private String location;
	private String phoneNum;
	private String fcm;
}

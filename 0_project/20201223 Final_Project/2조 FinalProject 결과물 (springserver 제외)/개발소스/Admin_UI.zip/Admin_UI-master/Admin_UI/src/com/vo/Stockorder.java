package com.vo;

public class Stockorder {
	
	private String itemname;
	private int amount;
	private String status;
}
